export class Hero {
  id:number;
  firstName: string;
  lastName: string;
  address: string;
  country: string;
}


